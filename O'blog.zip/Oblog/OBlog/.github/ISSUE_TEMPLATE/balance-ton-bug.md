---
name: Balance ton bug
about: Il y a une erreur dans l'énoncé ou le code
title: ''
labels: Bug

---

### Balance ton bug

Une description claire et concise du bug

### Importance

de 1 (osef) à 5 (la planète est en danger!) : :one: :two: :three: :four: :five:

### Solution

Si tu as une solution, tu peux la décrire ici, et/ou faire une PR

[x] je m'occupe de la PR résolvant le bug :muscle:
(:arrow_up: à supprimer si tu ne te charge pas la PR :wink:)