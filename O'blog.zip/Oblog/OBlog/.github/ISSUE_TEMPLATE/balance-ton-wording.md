---
name: Balance ton wording
about: Il y a une erreur de typo, de wording, un énoncé pas clair, etc. (pas du code, mais que du français)
title: ''
labels: Wording

---