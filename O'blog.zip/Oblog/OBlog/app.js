//Initialisation des package et autre

let express = require('express')
let app = require('express')()
let bodyParser = require('body-parser')
let session = require('express-session')
const fs = require('fs');
const { log } = require('console');
const { request } = require('http');
app.set('view engine', 'ejs');

app.use('/static', express.static('static'));


let articleData = require('./data/articles.json')

//Mise en place du serveur et des "/" donnant les pages

app.get('/' , (request , response) => {
    response.render('pages/index' ,  {articleData});
})



app.get('/article/:id' , (request , response) => {
    let json = fs.readFileSync('data/articles.json');

    let jsondata = JSON.parse(json);

    const id = parseInt(request.params.id);

    if (id > jsondata.length || id < 1) {
        response.status(404).send("Error 404: Page not Found");
    } else {
        let rawdata = fs.readFileSync('data/articles.json');
        let data = JSON.parse(rawdata);
        const article = data.find(data => data.id === id);
        response.render('pages/article', {article});
        
    }
})

app.get('/article' , (request, response) => {
    let json = fs.readFileSync('data/articles.json');
    let data = JSON.parse(json);

    const sortedData = data.sort((a, b) => a.category.localeCompare(b.category));
    console.log(sortedData);
    response.render('pages/trie' , { sortedData: sortedData })
})




app.listen(3000)